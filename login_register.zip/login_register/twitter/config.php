<?php
define('CLIENT_ID', 'SkVON1dEWUZZc0lQT3R4ZTZhQTA6MTpjaQ');
define('CONSUMER_SECRET', getenv('N5P6rSigfPRqVKQPJvl2ZYduPz_2dS4vDe0ssORETILoMxyM0n'));
define('REDIRECT_URL', 'https://www.a2zwebhelp.com/login_register/signuptwitter.php');
?>