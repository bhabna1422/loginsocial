<?php
$mailHost 		= "mail.a2zwebhelp.com";
$mailUsername   = "contact@a2zwebhelp.com";
$mailPassword   = "H%hlF-OO*DC";
$mailPort       = 587;
$Sender			= "contact@a2zwebhelp.com";
?>