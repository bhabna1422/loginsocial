<?php

/* Google App Client Id */
define('CLIENT_ID', '623959885862-l91bujrmmg33m5cl2rpdm988c29ggk63.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'LF3RupE5HXGXpIoD0N8ptjCA');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL_GOOGLE', 'https://a2zwebhelp.com/login_register/signupgoogle.php');

?>