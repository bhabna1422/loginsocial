<?php

/* Facebook App Client Id */
define('App_ID', '602553571099460');

/* Facebook App Client Secret */
define('App_Secret', 'fe6a0013b1cc918234d7fbc893d0dc26');

/* Facebook Client Token */
define('Client_Token', '1d1f9c16fef600253949b19ef15ad11d');

/* Facebook App Redirect Url */
define('CLIENT_REDIRECT_URL', 'https://a2zwebhelp.com/login_register/fbconfig.php');

?>